﻿namespace MyHealth.Model
{
    public enum Gender
    {
        Male = 0,
        Female = 1
    }
}
